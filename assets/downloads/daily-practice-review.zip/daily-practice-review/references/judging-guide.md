# How to judge the results

Use these rules every time so that every assistant reaches the same conclusions from the same data.

## 1. Sort every wrong or slow answer into one kind

| Kind | Meaning | Typical evidence |
| --- | --- | --- |
| `concept` | Doesn't understand it yet | Same type wrong more than once; wrong in a consistent way (e.g. 52 − 27 = 35: subtracted the smaller digit); not fixed in redo |
| `careless` | Knows it, slipped | Wrong once, similar items right, fixed on the first redo |
| `speed` | Right but not automatic | Correct, but slower than the speed limit below |
| `format` | Knew the answer, entered it wrongly or missed a mark for presentation | Right numbers in the wrong form (`31` then `r 2` for `31 r 2`); `"strict": true` text right except capitals or full stop; tapped "I'm not sure" on the first ever question of a new type |
| `not-attempted` | Skipped, "I'm not sure" (`given: ""`), part missing, paper task not done | |

Always look at `redo`: fixed on the first redo usually means `careless`; never fixed means `concept`.
Look at what was typed, not only whether it was right: `7 + 8 = 16` is "one off" (counting on and miscounting);
`47 + 6 = 43` is "forgot to carry".

If `sheets` gives the day sheet, check it for `"strict": true`, `keypad` and the exact answers expected before
blaming the child.

## 2. Speed limits per question

| Work | Automatic | Not yet automatic |
| --- | --- | --- |
| Addition and subtraction facts to 20 | ≤ 3 s | > 3 s; > 6 s is counting |
| Times tables and division facts | ≤ 4 s | > 4 s; > 8 s is skip-counting |
| 2-digit mental (47 + 6) | ≤ 8 s | > 15 s |
| Written methods, fractions of amounts, word problems | no limit | flag only if over 2 minutes |
| Word reading (`judge`) | ≤ 2 s | > 3 s is sounding out |

A check-up level's `fluentMs`, when set, replaces the table. Use the **median** time of a group, not single
items: one long time can be a distraction. On the very first session with the app, say that times may
include learning the app.

## 3. Accuracy bands (first try)

- **Secure**: 90% or more right first time **and** within the speed limit.
- **Accurate but slow**: 90%+ right, median over the limit. This is a fluency need, not a concept gap.
- **Shaky**: 70–89% right.
- **Gap**: under 70%, or a consistent wrong pattern on 2 or more items.
- **Not seen**: no data yet. Never guess a status without data.

Small samples: with fewer than 4 items of a kind, say "early sign" and set `confidence` to `low`.

## 4. Reading

- Accuracy: 95%+ is independent reading level; 90–94% is learning level; under 90% is too hard.
- Words correct per minute, approximate 50th percentile (Hasbrouck & Tindal, 2017, US norms; use as a rough
  guide only):

  | Grade | Start of year | Middle | End |
  | --- | --- | --- | --- |
  | 2 | 50 | 72 | 89 |
  | 3 | 83 | 97 | 112 |
  | 4 | 94 | 120 | 133 |
  | 5 | 121 | 133 | 146 |

- Compare speed on stories and on information texts separately: information texts are usually slower.
- Comprehension: 4/4 right with quick answers is secure. Wrong `inference` questions matter more than wrong
  `literal` ones.
- A count of 0 mistakes on every passage may mean the grown-up didn't count closely. Mention it gently.

## 5. Vocabulary (the word kitty)

Every question about a word's meaning tells you about one word. Find them by:
- `skill` starting with `vocabulary:` (for example `vocabulary:enormous`; the word is after the colon),
- `skill` equal to `vocabulary` (take the word from the prompt, usually in quotes),
- check-up station `vocab` items (the word is in quotes in `q`; the level name gives its grade).

Sort each word, using all its results in the bundle, newest last:

| Status | Rule |
| --- | --- |
| `known` | Right first time, and either answered within 8 s or right on 2 different days |
| `learning` | Right once after being wrong, or right but slower than 8 s, or seen only once and right |
| `not-yet` | Wrong first time on its latest try, or "I'm not sure" |

Estimate the level from the `vocab` station: `secureLevel` is the highest grade of words he knows well;
`stoppedAt` is where new words should come from. Without the station, use the grade of the passages he reads at
95%+ accuracy. Words he met in a passage and answered right count as `learning`, not `known`, until seen again.

To grow the kitty: about 5 new words a week from the `stoppedAt` level, chosen from his reading
(useful "Tier 2" words such as *enormous, reluctant, gather, curious*, not rare technical words), and each
`learning` word revisited after 2, 7 and 21 days until it is `known`.

## 6. Engagement: what he likes, and how he behaves when keen or bored

Newer results have `engagement` on each item, `tags` (theme and kind), `difficulty`, part `startedAt`/`endedAt`,
and Pip's `chats`. Older results don't; say "not enough data" rather than guess.

Per item signals (see the result format):

| Signal | Keen / engaged | Switched off / disinterested |
| --- | --- | --- |
| `firstInputMs` | Quick start for the difficulty | Long wait before the first tap |
| `idleMs`, `longestIdleMs` | Little idle time | Long gaps (10 s+) without touching anything |
| `backgroundMs` | 0 | Left the app mid-question |
| Speed vs accuracy | Steady pace, right | **Very fast and wrong** (guessing, rushing) |
| `edits` | A few (checking work) | None at all with wrong answers, or many with no progress |
| `hearAgain`, `lookBack` | Used when needed (care) | Never used on questions answered wrongly |
| Open answers, chat answers | Longer, specific, enthusiastic | One word, skipped |
| Check-up "Keep going" | Chose to go on | "That's enough" early |
| Over the session | Pace holds | Pace drops and idle grows towards the end (fatigue) |

How to judge:
- **Compare like with like.** Group items by theme tag and by kind tag. Compare their median `firstInputMs`
  and `idleMs` *relative to difficulty* (harder questions naturally take longer), and their accuracy.
- Call a theme or kind **high** engagement when it has quicker starts, less idle and better or equal accuracy
  than the child's own average; **low** when it has slower starts, more idle, more skips or rushed wrong answers.
  Fewer than 6 items or fewer than 2 days: **not-enough-data**.
- Use **time of day** (`startedAt`) to find his best practice time, and look for fatigue late in sessions.
- **His own words in Pip's chats count most.** Agreement between chats and behaviour gives high confidence.
- Describe behaviour, not personality. Never diagnose. One day is a clue; two weeks is a pattern.

### Genie hints and reading checks

- Items may have `hints` (the 🪔 wishes he used). **Hint reliance by topic** is strong evidence: needing hints on
  most "how many more" problems but none on "altogether" problems points at comparison language, not subtraction.
  An answer right only after a hint counts as `shaky`, not `secure`. Report wishes per day and per topic.
- `readingCheck` (or a separate `type: "reading-check"` file) is the genie's Whisper check of a read-aloud:
  `runningRecord.accuracy`, `wordsCorrectPerMinute`, `changed` and `skipped` words. Use it when no grown-up counted
  mistakes, but say it's approximate: speech-to-text mishears accents and names, so treat `changed` words as
  "places to listen to" in the recording, and look for patterns (dropping -ed endings, guessing long words).

## 7. In his own words (Pip's chats)

List what he said: likes, dislikes, what he'd build or choose, what was fun or hard, and mood answers by date.
Quote him briefly and exactly. Note skipped chats without judging them. If a mood answer is "Not great" on
several days, or an answer suggests he is upset, tell the parent gently and suggest they talk with him.

## 8. Recordings

Read-aloud results may have `recordingFile` (in the results repo's `recordings/` folder). Mention it so the
parent can listen, especially when mistakes were not counted or accuracy dropped.

## 9. The basics to check, by grade

Mark each one `secure`, `shaky`, `gap` or `not-seen` from the evidence.

- **Grade 2–3 foundations**: number bonds to 10 and 20; addition and subtraction facts to 20; place value to
  1,000; 2-digit adding and subtracting with carrying and borrowing; 2, 5, 10 times tables; o'clock, half past
  and quarter times; halves and quarters; phonics including digraphs and long vowels; full stops and capitals.
- **Grade 4**: all times tables to 10 × 10 and division facts; place value to 10,000 and rounding; column
  methods with 3–4 digits; 2-digit × 1-digit; division with remainders; fractions of amounts and equivalent
  fractions; time to the minute; reading Grade 4 texts at 95%+ accuracy; past tense, plurals, pronouns, speech
  marks, commas in lists; writing 5+ connected sentences.

## 10. Oral checks for the parent

For each `needsWork` item with medium or low confidence, give the parent two or three things to ask or do
with the child, away from the tablet, that take under two minutes. Say what a secure answer sounds like and
what a gap sounds like. Examples:

- Facts slow: "What's 7 + 8? How did you work it out?" Secure: answers at once or uses a strategy
  ("7 + 7 is 14, plus 1"). Gap: counts on fingers from 7.
- Remainders: "Share 17 sweets between 5 friends. How many each, and how many left over?" Secure: "3 each,
  2 left." Then show how the app wants it typed: `3 r 2`.
- Past tense with punctuation: "Write 'I walk to school' as yesterday." Watch for the capital I and the full
  stop.
- Vocabulary: "Tell me what *reluctant* means, and use it in a sentence." Secure: a right meaning and a
  sentence that fits. Learning: knows it's about feelings but not exactly. Not yet: guesses.

Ask the child to explain their thinking out loud. The explanation shows understanding better than the answer.
