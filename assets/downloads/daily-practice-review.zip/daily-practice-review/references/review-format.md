# Review format (reviewVersion 1): the review skill's output

The skill outputs a readable report **and** this JSON. The JSON goes into the learner profile as its `review`
field, which the daily-practice-sheet skill reads to decide what the next sheets practise.

```json
{
  "reviewVersion": 1,
  "learner": { "name": "Arjun", "grade": 4, "age": 9 },
  "period": { "from": "2026-10-04", "to": "2026-10-10" },
  "basedOn": { "dailySheets": 5, "checkupStations": ["add", "wordread", "readaloud"] },
  "summary": "Strong, accurate reader. Addition facts are right but counted, not known.",
  "strengths": [
    { "area": "english:reading", "detail": "Reads Grade 4 text with 100% accuracy and full comprehension",
      "evidence": "Read aloud: 3 passages, 0 mistakes, 12/12 questions" }
  ],
  "needsWork": [
    { "area": "math:addition-facts", "kind": "speed", "detail": "Facts to 20 are right but take about 8 s each",
      "evidence": "18/20 right, median 7.9 s (limit 3 s); 6 + 6 took 32 s", "confidence": "medium",
      "parentCheck": "confirmed" }
  ],
  "basics": [
    { "skill": "Addition facts to 20", "status": "shaky" },
    { "skill": "Times tables to 10 × 10", "status": "not-seen" }
  ],
  "nextTargets": [
    { "subject": "math", "target": "Addition facts to 20 to under 3 s each, near doubles first (7 + 8, 6 + 7)",
      "howOften": "every day, 5 minutes, 15–20 facts", "until": "two days in a row at 90%+ within 90 s for 20" }
  ],
  "vocabulary": {
    "estimatedLevel": "Grade 4 words",
    "learnNextFrom": "Grade 5 words",
    "known": ["chlorophyll", "prepare", "drifted"],
    "learning": [{ "word": "reluctant", "lastSeen": "2026-10-08", "reviewOn": "2026-10-15" }],
    "notYet": [{ "word": "enormous", "lastSeen": "2026-10-09", "reviewOn": "2026-10-11" }],
    "suggestedNewWords": ["curious", "gather", "exhausted", "fragile", "astonished"]
  },
  "engagement": {
    "summary": "Robot and car questions get quick starts and no idle time; plain sums get slower starts.",
    "byTheme": [{ "theme": "robots", "signal": "high", "evidence": "median first tap 2.1 s vs his 4.0 s average; 9/10 right" }],
    "byKind": [{ "kind": "teaser", "signal": "high", "evidence": "chose 'Keep going'; long chat answer about puzzles" }],
    "bestTime": "Before 7 pm; after 8 pm idle time doubles",
    "signsOfExcitement": ["Fast first taps", "Long, detailed open answers about robots"],
    "signsOfDisinterest": ["Very fast wrong answers on the last 3 sums", "Skipped the chat at the end"],
    "confidence": "low"
  },
  "aboutHim": {
    "likes": ["Cozmo", "Tesla Model Y", "puppies"],
    "dislikes": ["long spelling lists"],
    "mood": [{ "date": "2026-10-05", "said": "😀 Great" }],
    "quotes": ["A robot that walks my dog"]
  },
  "checkNext": ["Do the Adding, Taking away and Times tables check-up stations"],
  "notes": "First session with the app; times may include learning it."
}
```

| Field | Rule |
| --- | --- |
| `summary` | One or two plain sentences |
| `strengths` / `needsWork` | Each with `area` (`subject:topic`), `detail` and concrete `evidence` (numbers, items, times) |
| `needsWork[].kind` | `concept`, `careless`, `speed`, `format` or `not-attempted` (see judging-guide.md) |
| `needsWork[].confidence` | `high` (4+ items, consistent), `medium`, or `low` (an early sign from 1–3 items) |
| `needsWork[].parentCheck` | `confirmed`, `not-confirmed` (the oral check showed it's fine), or `not-checked` |
| `basics` | The grade's basics from judging-guide.md section 9, each `secure`, `shaky`, `gap` or `not-seen` |
| `nextTargets` | At most 4, most important first. Concrete enough to write a sheet from: what, how much, until when |
| `vocabulary` | The word kitty, sorted by judging-guide.md section 5. Carry forward words from the previous review (in the learner profile) and update them with new evidence. `reviewOn` is when the word should next appear on a sheet (2, 7, then 21 days after it was last seen). `suggestedNewWords`: about 5 words from the `learnNextFrom` level, useful in his reading, not already in any list |
| `engagement` | judging-guide.md section 6. `signal` is `high`, `medium`, `low` or `not-enough-data`; every one with evidence |
| `aboutHim` | judging-guide.md section 7: what he said in Pip's chats, quoted exactly |
| `checkNext` | Check-up stations or questions that would fill the biggest `not-seen` gaps |

Rules:
- Every claim cites evidence from the bundle. No evidence, no claim.
- `format` problems become a `nextTargets` item about how to answer (for example a worked example on the
  sheet), not extra practice of the maths.
- Items the parent marked `not-confirmed` stay in the JSON with that value, but are left out of `nextTargets`.
