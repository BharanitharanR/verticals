# Results bundle format (bundleVersion 1): the review skill's input

A results bundle is the child's raw result files from the Daily Practice app, wrapped with a little
context. `tools/collect_results.py` builds it from the results repo. You can also build it by hand:
put the result files, unchanged, in `results`.

```json
{
  "bundleVersion": 1,
  "learner": { "name": "Arjun", "grade": 4, "age": 9, "locale": "en-IN" },
  "period": { "from": "2026-10-04", "to": "2026-10-10" },
  "collectedAt": "2026-10-10",
  "results": [ { ...one daily result file... }, { ...one check-up result file... } ],
  "sheets": { "2026-10-04": { ...optional: the day sheet that was used... } },
  "parentNotes": "First time using the app. Was tired."
}
```

| Field | Meaning |
| --- | --- |
| `learner` | Grade and age matter most; they set the expectations |
| `period` | The dates the results cover |
| `results` | Result files exactly as the app wrote them (formats below) |
| `sheets` | Optional. The day sheets, keyed by date. They show settings the results don't, such as `"strict": true` |
| `parentNotes` | Anything that affects how to read the results |

## Daily result (from a day sheet)

Files named `YYYY-MM-DD_HHMMSS.json`. Has no `type` field.

```json
{
  "schemaVersion": 1, "date": "2026-10-04", "contentTitle": "Week 1, Monday", "completedAt": "2026-10-04T18:42:10",
  "math": {
    "skill": "M1", "label": "Addition facts to 20", "targetSeconds": 90,
    "firstPassSeconds": 104.2, "totalSeconds": 150, "firstPassCorrect": 18, "total": 20,
    "items": [
      { "id": "m7", "prompt": "7 + 8", "expected": "15", "given": "16", "correct": false, "ms": 8844,
        "review": false, "redo": [{ "given": "15", "correct": true, "ms": 4631 }] }
    ]
  },
  "english": {
    "passageTitle": "Pip the Pencil", "wordCount": 91,
    "reading": { "seconds": 58.3, "recorded": true, "mistakes": 2, "wordsCorrectPerMinute": 92 },
    "totalSeconds": 300, "firstPassCorrect": 2, "autoMarked": 3,
    "items": [
      { "id": "e3", "type": "open", "skill": "inference", "prompt": "Why ...?", "expected": "",
        "given": "as Ezzy helped Pip", "correct": null, "ms": 44135 }
    ]
  },
  "paperTasks": [{ "id": "p1", "subject": "Writing", "instruction": "...", "done": false }]
}
```

- `correct` is the **first** try. `redo` holds up to two fix-it tries; after that the app showed the answer.
- `ms` is the time on that question, in milliseconds, from when it appeared to when it was answered.
- `given` is exactly what was typed or chosen; `""` means the child tapped "I'm not sure".
- `correct: null` means not auto-marked (`open` questions): read `given` yourself.
- `firstPassSeconds` is the time for the whole first pass. `targetSeconds` is the mastery time.
- `mistakes`/`wordsCorrectPerMinute` are `null` if no grown-up counted mistakes.
- `english` items can be `choice`, `text`, `open`, `num`, `spell`, `tap` or `judge`. For `spell` and
  `judge` the `prompt` is the word. A `judge` item's `given` is `read correctly` or `not yet`.
- A part that is missing was not finished.
- Newer files also have: `engagement` on items (time to first tap, touches, edits, idle and background
  time, hear-again and look-back taps), `tags` and `difficulty` on items, `startedAt`/`endedAt` on parts,
  `teasers` (a Brain teasers part, items like English), `chats` (Pip's chats: `prompt`, `given`, `skipped`,
  `ms`, `at`) and `english.reading.recordingFile`. The full definition is in the app repo's
  `schemas/result.schema.json` and `CONTENT_SCHEMA.md`.

## Check-up result (one Pencil Box station)

Files named `YYYY-MM-DD_HHMMSS_checkup-<station>.json`, with `"type": "checkup"`.

```json
{
  "schemaVersion": 1, "type": "checkup", "date": "2026-10-04", "station": "add", "name": "Adding",
  "subject": "math", "kind": "ladder", "startedAt": "...", "finishedAt": "...",
  "secureLevel": "Addition facts to 20", "stoppedAt": "2-digit + 1-digit", "stoppedEarly": false,
  "allLevels": ["Adding within 10", "Addition facts to 20", "2-digit + 1-digit", "..."],
  "levels": [{ "name": "Adding within 10", "asked": 5, "correct": 5, "passed": true, "medianMs": 2100, "fluentMs": 3000 }],
  "items": [{ "level": "Adding within 10", "q": "4 + 6 =", "type": "num", "expected": "10", "given": "10", "correct": true, "ms": 1900 }]
}
```

- Each station is a ladder: a level is passed with enough right answers, and it stops at the first level
  not passed. `secureLevel` is the last level passed; `stoppedAt` the first one not passed (`null` = passed all).
- `stoppedEarly: true` means the child chose to stop, not that a level was failed.
- `fluentMs` is the speed target per question for that level (`null` = no target).
- Stations: `add`, `sub`, `place`, `mul`, `div`, `frac`, `story`, `clock` (math); `wordread` (a grown-up marks
  each word), `spell`, `readaloud`, `grammar`, `vocab` (word meanings, Grade 2 to Grade 6 levels), `writing` (English).
- `kind: "reading"` adds `passages`: `title`, `words`, `seconds`, `mistakes`, `accuracy` (%),
  `wordsCorrectPerMinute`, `questionsCorrect`, `questions`, `passed`. A passage passes with 90%+ accuracy
  and 3 of 4 questions right.
- `kind: "writing"` has `writing`: `prompt`, `text` (`null` if written on paper), `minutes`, `sentences`, and
  `ratings` (check → `yes` / `partly` / `not yet`) given by the grown-up.
