#!/usr/bin/env python3
"""Check that a review JSON matches references/review-format.md.

Usage: python3 check_review.py reviews/2026-10-10.json
Needs Python 3.9+.
"""
import json
import re
import sys

KINDS = {"concept", "careless", "speed", "format", "not-attempted"}
CONF = {"high", "medium", "low"}
CHECK = {"confirmed", "not-confirmed", "not-checked"}
STATUS = {"secure", "shaky", "gap", "not-seen"}
DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def check(d):
    errs = []
    req = lambda c, m: c or errs.append(m)
    req(d.get("reviewVersion") == 1, "reviewVersion must be 1")
    req(isinstance(d.get("summary"), str) and d["summary"].strip(), "needs a summary")
    for key in ("strengths", "needsWork"):
        req(isinstance(d.get(key), list), f"{key} must be a list")
        for i, x in enumerate(d.get(key) or []):
            for f in ("area", "detail", "evidence"):
                req(isinstance(x.get(f), str) and x[f].strip(), f"{key}[{i}] needs '{f}'")
    for i, x in enumerate(d.get("needsWork") or []):
        req(x.get("kind") in KINDS, f"needsWork[{i}].kind must be one of {sorted(KINDS)}")
        req(x.get("confidence") in CONF, f"needsWork[{i}].confidence must be one of {sorted(CONF)}")
        req(x.get("parentCheck") in CHECK, f"needsWork[{i}].parentCheck must be one of {sorted(CHECK)}")
    for i, x in enumerate(d.get("basics") or []):
        req(x.get("status") in STATUS, f"basics[{i}].status must be one of {sorted(STATUS)}")
    targets = d.get("nextTargets") or []
    req(len(targets) <= 4, "at most 4 nextTargets")
    for i, x in enumerate(targets):
        req(isinstance(x.get("target"), str) and x["target"].strip(), f"nextTargets[{i}] needs 'target'")
    v = d.get("vocabulary")
    if v is not None:
        seen = {}
        for lst in ("known", "learning", "notYet"):
            for w in v.get(lst) or []:
                word = (w if isinstance(w, str) else w.get("word", "")).lower()
                req(word, f"vocabulary.{lst} has an empty word")
                if word in seen:
                    errs.append(f"'{word}' is in both vocabulary.{seen[word]} and vocabulary.{lst}")
                seen[word] = lst
                if lst != "known":
                    req(isinstance(w, dict) and DATE.match(str(w.get("reviewOn", ""))),
                        f"vocabulary.{lst} '{word}' needs reviewOn YYYY-MM-DD")
        for w in v.get("suggestedNewWords") or []:
            if w.lower() in seen:
                errs.append(f"suggested new word '{w}' is already in vocabulary.{seen[w.lower()]}")
    return errs


def main(paths):
    if not paths:
        print(__doc__.strip())
        return 2
    bad = False
    for p in paths:
        try:
            errs = check(json.load(open(p, encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as e:
            errs = [f"not valid JSON: {e}"]
        print(f"{p}: {'OK' if not errs else 'PROBLEMS'}")
        for e in errs:
            print(f"  ERROR  {e}")
        bad = bad or bool(errs)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
