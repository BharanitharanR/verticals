#!/usr/bin/env python3
"""Make a results bundle (references/results-bundle.md) for the daily-practice-review skill.

Usage:
  python3 collect_results.py --github BharanitharanR/daily-practice-results --grade 4 --age 9 > bundle.json
  python3 collect_results.py --dir path/to/results --from 2026-10-04 --to 2026-10-10 --grade 4 > bundle.json

Options:
  --sheets OWNER/REPO   also include the day sheets used (from the content repo), so the review can see
                        settings such as strict marking. Works with --github only.
  --from / --to         only results dated in this range (inclusive). Default: the last 14 days.
  --notes TEXT          context for the reviewer (first session, tired, ...).

--github and --sheets use the GitHub CLI (gh), which must be logged in. Needs Python 3.9+.
"""
import argparse
import datetime
import json
import os
import subprocess
import sys


def gh_json(path, raw=False):
    args = ["gh", "api", path] + (["-H", "Accept: application/vnd.github.raw+json"] if raw else [])
    out = subprocess.run(args, capture_output=True, text=True)
    if out.returncode != 0:
        return None
    return json.loads(out.stdout)


def from_github(repo):
    listing = gh_json(f"repos/{repo}/contents/results") or []
    for f in listing:
        if f.get("type") == "file" and f["name"].endswith(".json"):
            data = gh_json(f"repos/{repo}/contents/results/{f['name']}", raw=True)
            if isinstance(data, dict):
                yield f["name"], data


def from_dir(path):
    for name in sorted(os.listdir(path)):
        if name.endswith(".json"):
            try:
                with open(os.path.join(path, name), encoding="utf-8") as f:
                    yield name, json.load(f)
            except json.JSONDecodeError:
                print(f"skipping {name}: not valid JSON", file=sys.stderr)


def date_of(name, data):
    return str(data.get("date") or data.get("finishedAt") or name)[:10]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--dir")
    src.add_argument("--github", metavar="OWNER/REPO")
    p.add_argument("--sheets", metavar="OWNER/REPO")
    p.add_argument("--from", dest="date_from")
    p.add_argument("--to", dest="date_to")
    p.add_argument("--name")
    p.add_argument("--grade", type=int)
    p.add_argument("--age", type=int)
    p.add_argument("--locale", default="en-IN")
    p.add_argument("--notes")
    a = p.parse_args()

    today = datetime.date.today()
    date_to = a.date_to or today.isoformat()
    date_from = a.date_from or (today - datetime.timedelta(days=14)).isoformat()
    files = from_github(a.github) if a.github else from_dir(a.dir)
    results = [(n, d) for n, d in files if date_from <= date_of(n, d) <= date_to]
    results.sort(key=lambda nd: nd[0])

    sheets = {}
    if a.sheets:
        for date in sorted({d.get("date") for _, d in results if d.get("type") != "checkup" and d.get("date")}):
            sheet = gh_json(f"repos/{a.sheets}/contents/days/{date}.json", raw=True)
            if isinstance(sheet, dict):
                sheets[date] = sheet

    learner = {k: v for k, v in (("name", a.name), ("grade", a.grade), ("age", a.age), ("locale", a.locale))
               if v is not None}
    bundle = {"bundleVersion": 1, "learner": learner, "period": {"from": date_from, "to": date_to},
              "collectedAt": today.isoformat(), "results": [d for _, d in results]}
    if sheets:
        bundle["sheets"] = sheets
    if a.notes:
        bundle["parentNotes"] = a.notes
    json.dump(bundle, sys.stdout, indent=1, ensure_ascii=False)
    print()
    print(f"{len(results)} result files from {date_from} to {date_to}"
          + (f", {len(sheets)} sheets" if sheets else ""), file=sys.stderr)


if __name__ == "__main__":
    main()
