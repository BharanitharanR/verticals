# daily-practice-review

A skill that goes through a child's Daily Practice results with the parent: strengths, what needs work and
why, whether the basics are secure, and the size of their word kitty. It works the same way in Claude,
ChatGPT and Grok because it is plain instructions plus reference files.

Every run follows the same four steps:

1. **Asks for the inputs**: the results bundle, the child's grade and age, the last review, your focus,
   context, and whether you can do a few quick oral checks.
2. **Confirms what it received** and what the data can and can't show.
3. **Shows the review** (one-minute summary, strengths, needs work, basics checklist, word kitty, quick oral
   checks, next targets) and asks you to confirm it or report the oral checks.
4. **Outputs the final review**: a plain report plus `reviews/YYYY-MM-DD.json`.

It separates three different things a wrong or slow answer can mean: not understanding (`concept`),
understanding but not yet fast (`speed`), and knowing it but entering it wrongly (`format`).

## How the two skills fit together

```
Kindle app results ──► collect_results.py ──► daily-practice-review ──► reviews/DATE.json
                                                                              │
daily-practice-sheet ◄── make_profile.py --review reviews/DATE.json ◄─────────┘
        │
        └──► days/DATE.json ──► Kindle app
```

The review's `nextTargets` and word kitty steer the next sheets: words come back on their review dates and
5 new words are added each week.

## Files

| File | What it is |
| --- | --- |
| `SKILL.md` | The instructions (the top block between `---` lines is for Claude; others ignore it) |
| `references/results-bundle.md` | The input format: the app's result files wrapped with context |
| `references/judging-guide.md` | The fixed rules for judging: error kinds, speed limits, accuracy bands, reading norms, word kitty, basics by grade, oral checks |
| `references/review-format.md` | The output JSON |
| `examples/example-review.json` | A review from made-up results, to show the format |
| `tools/collect_results.py` | Builds the results bundle from the results repo |
| `tools/check_review.py` | Checks a review JSON against the format |

## Use it

1. Make the bundle (needs the GitHub CLI, logged in). The last 14 days by default:

   ```bash
   python3 tools/collect_results.py --github BharanitharanR/daily-practice-results --sheets BharanitharanR/daily-practice-content --grade 4 --age 9 > bundle.json
   ```

2. Ask the skill to review his results and give it `bundle.json` (paste or attach).
3. Save the final JSON as `reviews/YYYY-MM-DD.json` in the content repo.
4. Next time you make sheets, build the profile with the review included:

   ```bash
   python3 ../daily-practice-sheet/tools/make_profile.py --github BharanitharanR/daily-practice-results --grade 4 --review reviews/YYYY-MM-DD.json > profile.json
   ```

In Claude Code you can just say "review his results": Claude runs steps 1, 3 and 4 itself, asking first.

## Set it up

Same as daily-practice-sheet: in Claude Code it's installed at `~/.claude/skills/daily-practice-review`;
on claude.ai upload the zip (Settings → Capabilities → Skills); in ChatGPT or Grok paste `SKILL.md` as the
instructions and attach the three `references/` files.
