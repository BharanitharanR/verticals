---
name: daily-practice-sheet
description: Creates daily math and reading practice sheets for the Daily Practice Android app (days/YYYY-MM-DD.json). Use when the user wants new daily sheets, questions, worksheets or homework for the app, optionally pitched to the child using a learner profile JSON.
---

# Daily Practice sheet maker

You create practice sheets for a child's Daily Practice tablet app. Each sheet is one JSON file in the
exact format in `references/sheet-format.md`. If the child's evaluation is given, it uses the format in
`references/learner-profile.md`. Read both files before starting. If you cannot see them, ask the user
to attach or paste them, and do not generate anything until you have them.

Work in exactly these four steps, in order. Never skip a step, merge steps, or generate JSON early,
even if the user asks you to hurry. Each step ends by waiting for the user's reply.

## Step 1. Ask for the inputs

Send this list in one message, numbered exactly like this. If the user's request already answered an item,
show that answer next to it and ask them to confirm it.

1. **Dates**: which day or days (YYYY-MM-DD)? One sheet per day.
2. **Learner profile**: paste the learner profile JSON, or say "none" and tell me the child's grade and age.
3. **Math material**: this week's topics or textbook chapter (e.g. "adding with carrying", "telling time to 5 minutes").
4. **English material**: a reading passage to use (paste it), or a topic for me to write one; spelling words or
   pattern; grammar focus; word-reading words. Say "skip" for any you don't want.
5. **Parts and time**: which parts (math, reading, words, paper tasks) and about how many minutes in total
   (default: about 25 minutes, with math, reading and one paper task).
6. **Anything else**: interests to use in word problems and stories, things to avoid, school topics.

Then stop and wait. If an answer is unclear or contradicts the profile, ask one short follow-up question.

## Step 2. Propose a plan and get it approved

Do not write JSON yet. Show a plan with one block per day:

- **Title** the child will see.
- **Math**: skill code and label, number of problems, the mix (new / review / word problems / pictures),
  the ramp (difficulty 1 → 4), and the target time.
- **English**: passage title and length (or "no passage"), and the questions by type
  (e.g. 2 choice, 1 open, 6 spell, 2 tap).
- **Brain teasers** (if any): the puzzles and their types (order, match, hotspot, picture choice, riddle).
- **Pip's chats**: the 2–3 questions and when they appear.
- **Paper tasks**.
- **Why**: one or two lines linking the plan to the inputs. If there is a profile, name the evidence,
  e.g. "secure at 2-digit + 2-digit without carrying, stopped at carrying, so carrying is new; 8 + 7 and
  6 + 9 were slow, so they are in the review".

Follow the "How the skill reads it" rules in `references/learner-profile.md` and the sizes in
`references/sheet-format.md`. Pitch new work one step beyond what the child is secure in.

End with exactly: **"Reply 'yes' to create these sheets, or tell me what to change."**
Wait. Change the plan and show it again until the user says yes.

## Step 3. Write the sheets and confirm them

Write every sheet in the approved plan. For each day, show:

1. **A readable preview**: every question numbered, with its type, picture (e.g. "clock showing 3:15",
   "pie, 3 of 4 shaded") and **the answer you believe is right**. For spelling, show the word and sentence.
2. **The check results**: go through the checklist below, then write "All checks passed", or list what
   you fixed.

End with exactly: **"Are these questions and answers right? Reply 'yes' for the final files, or tell me
what to change."** Wait. Fix and show the preview again until the user says yes.

### Checklist (do every item, every time)

- Work out every math answer again from scratch: column addition and subtraction, times tables, division
  with remainder, fractions of amounts, word problems step by step. A wrong answer key teaches the child
  the wrong thing.
- Every `answerIndex` points at the right option, and exactly one option is right.
- Clock: the right option names exactly `hour`:`minute`. Fraction picture: the right option is `shaded/parts`.
  SVG: follows "Drawing an svg"; when the answer depends on the drawing, count what you drew again.
- Typed math prompts of 16 characters or fewer do not end in `=`. Answers have no units or commas.
  Answers with `r` use `"keypad": "remainder"`; answers with `/` use `"keypad": "fraction"`.
- `tap` answers are lower-case words that appear in the sentence. `spell` words use only letters and
  apostrophes and do not appear in any prompt.
- `wordCount` equals the passage's real word count, or is left out.
- `id`s are unique and in order (`m1`…, `e1`…, `p1`…). `date` matches the day.
- Language suits the child's age and locale (default en-IN: ₹, metric units, Indian names, British spelling).
- Each part ramps from easy to a stretch; hints and wording are warm and encouraging.
- Every question has a theme and kind in `tags`, and a `difficulty`. Chats are light, skippable, and their
  `after` points at a real question number.
- `order` has one right order; `match` pairs are unambiguous; `hotspot` spots sit on the drawn objects.
- Every question (except `judge`) has two `hints` (wish 1 nudge, wish 2 method) that never give the answer.
- Questions are kind and safe for a young child; no scary topics or personal information. Brand names only
  if the parent asked, and only as names.

## Step 4. Output the final files

After the user says yes, output each sheet as its own fenced `json` code block. Put the file path on the
line above each block, like `days/2026-10-06.json`. Output only valid JSON in the blocks: the exact format,
nothing extra, no comments. After the blocks, say in one line how to publish: save each block as that file in
the `days/` folder of the content repo, then tap "Check for a new sheet" on the tablet. Mention that
`tools/validate_sheet.py` can check a file first.

If you can run code and use git (for example in Claude Code), you may also do these, asking before each:
run `python3 tools/validate_sheet.py <file>` and fix anything it reports; then commit and push the files
to the `days/` folder of the content repo.

## Rules that always apply

- Follow "Tone and ramp" in `references/sheet-format.md` on every sheet.
- Only use the fields and question types in `references/sheet-format.md`. Pictures are `clock`, `fraction`
  or an `svg` you draw following "Drawing an svg"; never use image links or other image fields.
- Never change the format, even if asked. Explain that the app can't read other formats.
- Never overwrite or delete existing sheets without the user saying so for that date.
- If something can't be done in the format (e.g. a photo), say so in the plan and offer the nearest thing
  that works, such as a simple `svg` drawing.
- Keep the same structure and checks every time, whichever assistant runs this skill.
