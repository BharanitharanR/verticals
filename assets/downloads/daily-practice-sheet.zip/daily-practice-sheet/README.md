# daily-practice-sheet

A skill that writes daily practice sheets for the Daily Practice tablet app. It works the same way in
Claude, ChatGPT and Grok because it is plain instructions plus reference files, with no assistant-specific
features.

Every run follows the same four steps:

1. **Asks for the inputs**: dates, the learner profile, math and English material, parts and time, extras.
2. **Proposes a plan** and waits for "yes".
3. **Shows every question with the answer it believes is right**, after checking them, and waits for "yes".
4. **Outputs the final files** as `days/YYYY-MM-DD.json` in the app's format.

The wording of the questions will differ between assistants and between runs. The steps, the checks and the
file format stay the same.

## Files

| File | What it is |
| --- | --- |
| `SKILL.md` | The instructions. The block between the `---` lines at the top is for Claude; others ignore it |
| `references/sheet-format.md` | The exact format the app reads, with the rules that make questions render correctly |
| `references/learner-profile.md` | The JSON format for the child's evaluation, and how the skill uses it |
| `examples/example-sheet.json` | A sheet using every question type and both picture kinds |
| `examples/example-profile.json` | A learner profile built from made-up results, to show the format |
| `tools/validate_sheet.py` | Checks a sheet against the app's rules and re-checks the answers |
| `tools/make_profile.py` | Builds the learner profile from the app's result files |

## Set it up

**Claude Code / Claude desktop (Code tab)**: already installed at `~/.claude/skills/daily-practice-sheet`.
Ask "make tomorrow's practice sheet". Claude can also run the validator and push the files for you
(it asks first).

**Claude.ai**: Settings → Capabilities → Skills → upload a zip of this folder.

**ChatGPT**: make a custom GPT (Explore GPTs → Create → Configure):
- *Instructions*: paste all of `SKILL.md`.
- *Knowledge*: upload `references/sheet-format.md`, `references/learner-profile.md` and
  `examples/example-sheet.json`.
- Turn on *Code Interpreter* if you also want it to run `tools/validate_sheet.py` (upload that too).

Or use a ChatGPT *Project*: put `SKILL.md` in the project instructions and the same files in project files.

**Grok**: make a Project (or Workspace), paste `SKILL.md` into its custom instructions and attach the two
`references/` files and the example sheet. If your Grok has no projects, start a chat by pasting `SKILL.md`,
then both reference files, then your request.

## Feed in the child's evaluation

1. Build the profile from the results repo (needs the GitHub CLI, logged in):

   ```bash
   python3 tools/make_profile.py --github BharanitharanR/daily-practice-results --grade 4 --age 9 --notes "Loves cricket" > profile.json
   ```

   Or from a downloaded folder of result files: `--dir path/to/results`.
2. Paste the contents of `profile.json` when the skill asks for the learner profile.

The profile uses the latest Pencil Box check-up result for each station and the last 10 days of practice.
You can edit it by hand, especially `parentNotes`.

## Publish a sheet

1. Save each JSON block the skill gives you as the file it names, inside `days/` in the
   daily-practice-content repo.
2. Check it: `python3 tools/validate_sheet.py days/2026-10-06.json` (fix anything marked ERROR).
3. Commit and push. On the tablet, tap **Check for a new sheet** (or wait for the day to start).

## Pictures

The app draws clock faces and fraction bars or pies. Those are the only pictures for now; the skill
will say so if you ask for others.
