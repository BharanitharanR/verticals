# Daily Practice sheet format (schema version 1)

This is the only output format. The Daily Practice Android app reads one file per day from
`days/YYYY-MM-DD.json` in the content repo. A file that breaks a **MUST** rule is rejected by
the app with "Today's sheet has a problem", so the child gets nothing that day.

## File

```json
{
  "schemaVersion": 1,
  "date": "2026-10-06",
  "title": "Week 2, Tuesday",
  "math": { ... },
  "english": { ... },
  "teasers": { ... },
  "chats": [ ... ],
  "paperTasks": [ ... ]
}
```

- MUST: `schemaVersion` is `1`; `date` is `YYYY-MM-DD` and matches the file name.
- `title` is shown to the child. Short and friendly ("Week 2, Tuesday", "Clocks and carrying").
- `math`, `english`, `teasers` and `paperTasks` are each optional, but include at least one. `chats` is optional.
- The machine-readable definition is `references/schemas/sheet.schema.json` (JSON Schema). This page adds the
  rules a schema can't check.
- Plain JSON only: double quotes, no comments, no trailing commas.

## `math`

```json
{
  "skill": "A5",
  "label": "Adding with carrying",
  "targetSeconds": 240,
  "problems": [ ... ]
}
```

| Field | Rule |
| --- | --- |
| `skill` | Short code for the level, e.g. `A5`, `M3`. Free text, used for analysis |
| `label` | Shown to the child above the problems |
| `targetSeconds` | Mastery time for the whole set. Recorded, never shown. Roughly 3–6 s per fact, 15–30 s per written method problem |
| `problems` | MUST be a non-empty array. Shown one at a time, in order |

Each problem is **either** a typed answer **or** multiple choice.

Typed answer:

```json
{ "id": "m1", "prompt": "47 + 38", "answer": "85" }
{ "id": "m2", "prompt": "29 ÷ 4", "answer": "7 r 1", "keypad": "remainder" }
{ "id": "m3", "prompt": "1/4 of 20", "answer": "5" }
{ "id": "m4", "prompt": "Ravi has 3 bags with 6 apples in each. How many apples?", "answer": "18" }
```

Multiple choice, optionally with a picture:

```json
{ "id": "m5", "prompt": "What time does the clock show?",
  "options": ["quarter past 3", "quarter to 3", "half past 3"], "answerIndex": 0,
  "visual": { "kind": "clock", "hour": 3, "minute": 15 } }
{ "id": "m6", "prompt": "What fraction is shaded?",
  "options": ["3/4", "1/4", "4/3"], "answerIndex": 0,
  "visual": { "kind": "fraction", "shape": "pie", "parts": 4, "shaded": 3 } }
```

| Field | Rule |
| --- | --- |
| `id` | MUST be unique in the file. Use `m1`, `m2`, … in order |
| `prompt` | MUST be present. See the prompt rules below |
| `answer` | MUST for typed problems. Digits only, or `7 r 1` (remainder), or `3/4` (fraction). No units, no commas in numbers |
| `accept` | Optional extra correct answers, e.g. `["1/2"]` for an answer of `2/4` |
| `keypad` | `digits` (default), `remainder` (adds an `r` key: MUST use for answers with `r`), `fraction` (adds `/`: MUST use for answers with `/`) |
| `review` | `true` for review problems from earlier levels |
| `options` | 2–4 different strings. Makes it multiple choice (no keypad) |
| `answerIndex` | MUST with `options`: 0-based index of the right option |
| `visual` | Optional picture, see Pictures |
| `tags` | Labels for analysis: always include one theme and one kind, e.g. `["robots", "word-problem"]` (see Tags) |
| `difficulty` | 1 (easiest) to 5. Use it to show the ramp: start at 1–2, end at 3–4 |
| `hints` | Two written genie hints (see Genie hints) |

Prompt rules for typed math:
- A prompt of 16 characters or fewer is shown huge and the app adds ` =` itself. So write `47 + 38`,
  **not** `47 + 38 =`.
- If the prompt already contains `=` (like `1/3 = ?/12`), the app adds nothing.
- Over 16 characters is shown as a word problem, with no ` =`. Write it as a full question.
- Use the symbols `+ − × ÷` (real minus, times and divide signs).
- Marking ignores spaces and capital letters, so `7r1`, `7 r 1` and `7 R 1` all count.

## Pictures

Three kinds. Use `clock` and `fraction` whenever they fit (the app draws them perfectly); use `svg` for
everything else.

```json
{ "kind": "clock", "hour": 3, "minute": 15 }
{ "kind": "fraction", "shape": "bar", "parts": 4, "shaded": 3 }
{ "kind": "svg", "height": 200, "svg": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 120'>...</svg>" }
```

- Clock: `hour` 1–12, `minute` 0–59 (use multiples of 5 for this age). The hour hand moves between numbers
  like a real clock. For "What time does the clock show?" the right option MUST name exactly this time.
  A clock can also show a starting time ("It starts at the time on the clock and lasts 30 minutes").
  Write times as `3 o'clock`, `half past 3`, `quarter past 3`, `quarter to 4`, or `3:25`.
- Fraction: `shape` is `bar` or `pie`; `parts` 1–24; `shaded` 0–`parts`. The first `shaded` parts are
  coloured. For "What fraction is shaded?" the right option MUST be `shaded/parts`.
- Pictures work on math problems, on every `english` question type, and on a passage
  (`"passage": { "title": ..., "text": ..., "visual": { ... } }`, drawn above the story).

### Drawing an `svg`

You write the drawing yourself as SVG code, in one JSON string.

- MUST: root `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 W H'>`. Use single quotes inside the SVG
  so the JSON string needs no escaping; if you use double quotes, escape them as `\"`. No line breaks in the
  string (or escape them as `\n`).
- MUST NOT use: `<script>`, `<foreignObject>`, `<image>`, `<animate…>`, event attributes (`onclick`…), links
  to anything outside the drawing (`href` may only point to `#id` inside it), or `url(http…)`.
  The app can't load them and the validator rejects them.
- At most 100,000 characters; aim for under 5,000. `height` 80–400 (default 220) sets the space it takes on
  screen; the drawing is scaled to fit and centred.
- Use simple shapes: `rect`, `circle`, `ellipse`, `line`, `polyline`, `polygon`, `path`, `g`, `text`.
  Give every shape an explicit `fill` (and `stroke` if outlined). It is drawn on white.
- App colours (friendly and consistent): pencil yellow `#F5B700`, ink blue `#2B5BD7`, eraser pink `#F6B3C0`,
  graphite `#2E3238`, green `#2E9E5B`, light rule `#D6E0F0`.
- Text in pictures: `font-family='sans-serif'`, `font-size` 14 or more in viewBox units for a 300-wide box.
- When the picture **is** the question (count the apples, read the bar chart, which shape has 4 sides),
  the drawing MUST match the answer exactly: count the objects you drew; the right bar has the right height.
  Describe the drawing in the preview so the parent can check it.
- Good uses: counting objects and arrays for multiplication (3 rows of 4 stars), shapes and symmetry,
  number lines, simple bar charts and pictograms, money (coins as labelled circles), measuring with a
  ruler, a small scene to illustrate a story or a vocabulary word.
- Keep it simple and clear. A plain, correct picture beats a detailed one.

Example: 3 rows of 4 counters for "3 × 4":

```json
{ "kind": "svg", "height": 160, "svg": "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 150'><g fill='#F5B700' stroke='#2E3238' stroke-width='2'><circle cx='25' cy='25' r='16'/><circle cx='75' cy='25' r='16'/><circle cx='125' cy='25' r='16'/><circle cx='175' cy='25' r='16'/><circle cx='25' cy='75' r='16'/><circle cx='75' cy='75' r='16'/><circle cx='125' cy='75' r='16'/><circle cx='175' cy='75' r='16'/><circle cx='25' cy='125' r='16'/><circle cx='75' cy='125' r='16'/><circle cx='125' cy='125' r='16'/><circle cx='175' cy='125' r='16'/></g></svg>" }
```

## `english`

```json
{
  "passage": { "title": "The Mango Cart", "text": "First paragraph.\n\nSecond paragraph.", "wordCount": 118 },
  "questions": [ ... ]
}
```

- `passage` is optional. With it, the child reads it aloud (timed), a grown-up counts mistakes, then
  the questions follow with a "look back at the story" button. Without it, the questions start straight away
  (good for a spelling or grammar day).
- Paragraphs are separated by `\n\n`. `wordCount` MUST equal the real number of words (or leave it out
  and the app counts).
- MUST have a passage or at least one question.

Question types:

```json
{ "id": "e1", "type": "choice", "skill": "literal", "prompt": "What did Mr Rao sell?",
  "options": ["Mangoes", "Bananas", "Ice cream"], "answerIndex": 0 }
{ "id": "e2", "type": "text", "skill": "grammar:past-tense", "prompt": "Write the past tense of run.",
  "accept": ["ran"] }
{ "id": "e3", "type": "open", "skill": "inference", "prompt": "Why did Anu help Mr Rao?" }
{ "id": "e4", "type": "num", "skill": "detail", "prompt": "How many wheels did the cart have?", "answer": "2" }
{ "id": "e5", "type": "spell", "skill": "spelling:-ed", "word": "jumped", "sentence": "The cat jumped onto the wall." }
{ "id": "e6", "type": "tap", "skill": "grammar:verb", "prompt": "Tap the doing word (verb).",
  "sentence": "The baby sleeps in the cot.", "accept": ["sleeps"] }
{ "id": "e7", "type": "judge", "skill": "phonics:long-vowel", "word": "boat" }
```

| Type | What happens | MUST have |
| --- | --- | --- |
| `choice` | Tap one option | `prompt`, `options` (2–4), `answerIndex` |
| `text` | Types a short answer. Ignores case, extra spaces and a final full stop (unless `"strict": true`, for capitals and punctuation practice) | `prompt`, `accept` (all acceptable answers) |
| `open` | Writes freely; not marked, saved for you to read | `prompt` |
| `num` | Number keys, marked like math | `prompt`, `answer` (+ `keypad` if needed) |
| `spell` | The tablet says the word, then "word. sentence. word."; the child types it on letter keys | `word`; `sentence` strongly recommended. Do NOT put the word in `prompt` |
| `tap` | The sentence's words become buttons; tapping a right one answers. Punctuation is ignored | `prompt`, `sentence`, `accept` (lower-case words that appear in `sentence`) |
| `judge` | The child reads `word` aloud; a grown-up taps "Read it right" or "Not yet" | `word` |
| `order` | Tap tiles into the right order (shown shuffled), then "Check my order" | `prompt`, `items` (2–8, **in the right order**) |
| `match` | Tap a left item, then its partner; wrong pairs shake off and count | `prompt`, `pairs` (2–6 `[left, right]`) |
| `hotspot` | Tap the right places on a picture; finds get a green ring, misses a red cross | `prompt`, `visual` (an `svg`), `spots` (1–10 `{x, y, r}` in viewBox units) |

- MUST: `id` unique (`e1`, `e2`, … in order); `type` is one of the ten above.
- Every question can also have `tags` and `difficulty`, as for math.
- `order` items, `match` pairs and `hotspot` spots must be unambiguous: exactly one right order, each left
  item has exactly one partner, every spot is clearly the thing asked for. For `hotspot`, make `r` generous
  (15+ in a 300-wide viewBox) and keep spots apart; check each spot's x, y really sits on the drawn object.
- `skill` is a free label for analysis: `literal`, `inference`, `grammar:<topic>`, `spelling:<pattern>`,
  `phonics:<pattern>`. For a word-meaning question use `vocabulary:<word>` (e.g. `vocabulary:reluctant`,
  lower case): the review skill uses it to track the child's word kitty. Put the word in the prompt in quotes:
  `What does "reluctant" mean in the story?`
- Optional `say`: a short hint Pip says above the question ("Use the r key for the remainder.").
- Wrong answers get two more tries at the end (except `open` and `judge`), then the app shows the answer.
- Spelling words only use letters and apostrophes (the letter keys have nothing else).

## Genie hints

Every math, reading and teaser question may carry `"hints": ["wish 1", "wish 2"]`. The 🪔 lamp shows them when
the genie in Adiyan isn't reachable (and the genie itself writes its own nudges when it is), so write them for
every question except `judge`:

- **Wish 1**: a gentle Socratic nudge to understand the question: what is it asking, what to notice first.
  *"Are we putting the laps together, or comparing which car drove more?"*
- **Wish 2**: a more specific nudge towards the method or next step. *"Which car drove more? Start with that
  number and take away the other."*
- MUST NOT contain the answer, part of it, or a sum whose result is it. At most 25 words each. Warm.
- Spelling: point to the sound or pattern (*"Listen for the ending: does it double a letter?"*), never the letters.

## `teasers`: the Brain teasers part

```json
"teasers": { "label": "Robot puzzles", "questions": [ ...questions of any type... ] }
```

A third button on the home screen. Puzzles come one at a time with **instant feedback** (a star and praise,
or Ezzy with the answer), so this is the place for the most interactive, game-like questions: `order`,
`match`, `hotspot`, picture `choice`, riddles, patterns, logic. Ids `t1`, `t2`, …. 3–6 puzzles, ramping
from very easy (difficulty 1) to a stretch (3–4).

Example ideas: order the cars from slowest to fastest; match each car maker to its model; match animals to
their babies; tap every triangle in a robot drawing; tap the robot that is different; what comes next in a
picture pattern; a riddle; "Ravi is taller than Meera, Meera is taller than Sam: who is shortest?".

## `chats`: Pip's chats

```json
"chats": [
  { "id": "c1", "prompt": "How are you feeling today?", "options": ["😀 Great", "🙂 Good", "😐 OK", "😕 Not great"], "after": "start" },
  { "id": "c2", "prompt": "If you could build any robot, what would it do?", "after": "math:6" },
  { "id": "c3", "prompt": "Which part was the most fun today?", "options": ["Maths", "The story", "Puzzles", "Spelling"], "after": "end" }
]
```

Friendly questions from Pip between practice questions, to learn what the child likes. Never marked or
scored, always skippable, each asked once.

- `after`: `start` (opening the first part), `end` (opening Finish and send), or `math:N`, `english:N`,
  `teasers:N` (after question N on the first pass, so N is at most the number of questions in that part).
- `options` (2–6, emoji welcome) for tap answers; leave it out for a typed answer.
- 2–3 a day: usually a mood check at `start`, one interest question in the middle, and "what was most fun"
  or "what was hardest" at `end`.
- Keep them light: favourites, would-you-rather, what they'd build or invent, how they feel, what was easy
  or hard, which theme they'd like next. Never family, friends' behaviour, fears, or anything private.
- Vary them from day to day; don't repeat the same question within a week (except the mood check).

## Tags

Use the same small set so results can be compared over time:
- **Theme** (one): `cars`, `robots`, `lego`, `animals`, `puppies`, `space`, `sport`, `everyday`, or the child's own interest.
- **Kind** (one): `fact`, `word-problem`, `picture`, `teaser`, `riddle`, `pattern`, `logic`, `comprehension`,
  `vocabulary`, `grammar`, `spelling`, `puzzle`.

## `paperTasks`

```json
[{ "id": "p1", "subject": "Writing", "instruction": "Write 3 sentences about your favourite animal." }]
```

Things done away from the tablet. The child ticks each one off before sending. Keep to 0–2.

## Tone and ramp (always)

- **Ramp gently** in every part: open with 2–3 easy wins (difficulty 1–2), build up, end with one stretch
  (3–4). Never open with the hardest question.
- **Praise and encourage throughout**: warm `say` hints ("You're doing brilliantly!", "Detectives check twice!"),
  stories where characters try again after a mistake, and a friendly title. Math problems have no `say`,
  so make their wording friendly.
- **Real names** (car makers and models, robots, toys) are fine when the parent asks for them. Use them as names
  only: make up the numbers ("Kabir's toy Model Y drove 46 laps"), don't state product facts that could be wrong.

## Sizes that work for one day (about 20–30 minutes)

- Math: 10–20 problems. Facts: 15–20. Written methods or word problems: 6–10. About 1 in 4 can be review.
- Reading: a passage of 80–250 words for Grade 2–4, with 4–6 questions (at least one `inference`).
- Spelling: 6–10 words. Grammar: 4–6 questions. Word reading (`judge`): 8–10 words.
- At most one long `open` question a day.
- Teasers: 3–6. Chats: 2–3.
