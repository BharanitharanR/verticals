# Learner profile format (profileVersion 1)

The learner profile tells the skill what the child can already do. Paste it when the skill asks.
`tools/make_profile.py` builds it from the app's result files; you can also write or edit it by hand.
Every field except `profileVersion` is optional. Missing parts just mean "not known yet".

```json
{
  "profileVersion": 1,
  "learner": { "name": "Arjun", "grade": 4, "age": 9, "locale": "en-IN" },
  "asOf": "2026-10-05",
  "checkup": {
    "add": {
      "name": "Adding", "date": "2026-10-05",
      "secureLevel": "2-digit + 2-digit, no carrying",
      "stoppedAt": "2-digit + 2-digit, with carrying",
      "levels": [{ "name": "Adding within 10", "correct": 5, "asked": 5, "passed": true, "medianMs": 2100, "fluentMs": 3000 }],
      "slow": [{ "q": "8 + 7", "ms": 4100 }],
      "missed": [{ "q": "38 + 45", "expected": "83", "given": "73" }]
    },
    "readaloud": {
      "name": "Read aloud", "secureLevel": "Passage 2 (about Grade 3)", "stoppedAt": "Passage 3 (about Grade 4)",
      "reading": [{ "title": "The Mango Cart", "wordsCorrectPerMinute": 82, "accuracy": 96.5, "questionsCorrect": 4, "questions": 4 }]
    },
    "writing": { "name": "Writing", "sentences": 5, "workOn": ["Uses capital letters and full stops"] }
  },
  "recentDays": [
    {
      "date": "2026-10-04", "title": "Week 1, Monday",
      "math": { "skill": "A5", "label": "Adding with carrying", "correct": 14, "total": 16,
                "firstPassSeconds": 260, "targetSeconds": 240,
                "missed": [{ "q": "47 + 38", "expected": "85", "given": "75" }],
                "slow": [{ "q": "29 + 56", "ms": 21000 }] },
      "english": { "correct": 3, "marked": 4, "wordsCorrectPerMinute": 78, "mistakes": 4,
                   "missed": [{ "q": "Why did ...?", "skill": "inference", "expected": "...", "given": "..." }] },
      "paperTasks": { "done": 1, "total": 1 }
    }
  ],
  "parentNotes": "Finds borrowing hard. Loves animals and cricket.",
  "review": { "reviewVersion": 1, "nextTargets": [ ... ], "vocabulary": { ... } }
}
```

## Fields

| Field | Meaning |
| --- | --- |
| `learner.grade` | School grade (number). Used when nothing else is known |
| `learner.locale` | `en-IN` (default): ₹, metric units, Indian names, British spelling |
| `checkup.<station>` | Latest Pencil Box check-up result per station. Station ids: `add`, `sub`, `place`, `mul`, `div`, `frac`, `story`, `clock`, `wordread`, `spell`, `readaloud`, `grammar`, `vocab`, `writing` |
| `secureLevel` | The hardest level passed. `null` = not secure at the first level |
| `stoppedAt` | The first level not passed. `null` = passed every level |
| `levels[].medianMs` / `fluentMs` | Typical time per question, and the speed target if there is one |
| `slow` | Right answers slower than the target: known but not automatic yet |
| `missed` | Wrong first answers, with what the child gave |
| `recentDays` | Newest first, up to 10 daily sheets. `firstPassSeconds` vs `targetSeconds` shows speed |
| `parentNotes` | Anything the grown-up wants the skill to know (interests, worries, school topics) |
| `review` | The latest review from the daily-practice-review skill (its review-format.md), added by `make_profile.py --review`. The important parts are `nextTargets`, `needsWork` and `vocabulary` |

## How the skill reads it

0. **A `review` comes first.** Build the sheets around its `nextTargets`, in order, as far as the time allows.
   Skip `needsWork` items marked `"parentCheck": "not-confirmed"`. A `format` target means showing how to answer
   (a `say` hint and a worked example in the prompt), not more of the same maths.
   **Vocabulary**: on each sheet, include as `choice` meaning questions (tagged `"skill": "vocabulary:<word>"`)
   every `learning` or `notYet` word whose `reviewOn` date is on or before the sheet's date, and about 1 of the
   `suggestedNewWords` per day (5 a week), used naturally in the passage. Don't retest `known` words.
   **Engagement**: lean towards themes and kinds marked `high` in `review.engagement` and things he named
   in `review.aboutHim.likes`; use `low` themes sparingly, mixed with favourites. Schedule harder work for his
   `bestTime` if the parent can.
1. **Next step** for each subject is the `stoppedAt` level: teach and practise that. `secureLevel` and below is
   review (about 1 in 4 problems).
2. **Slow but right** items become short fluency practice, repeated over several days.
3. **Missed** items: look for the pattern (forgot to carry, swapped hour and minute hands, -ed spelling) and
   target the pattern, not just the same question.
4. **Recent days** override the check-up when newer: 90%+ right and within target time on two days in a row
   means move on; under 70% means step back a level.
5. **Reading**: pick passages near the level of the last passage passed. As a rough guide, early Grade 4
   readers are around 90–100 words correct per minute.
6. **Writing** `workOn` points become the paper task or `open` question focus.
7. With no profile, use `learner.grade` (or ask for it) and start one step below grade level.
