#!/usr/bin/env python3
"""Check a Daily Practice sheet before publishing it.

Usage: python3 validate_sheet.py days/2026-10-06.json [more files...]

Errors are things the app would reject, or answers that are wrong. Warnings are things that will
work but look off. Exit code 1 if any file has errors. Needs only Python 3.9+.
"""
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from fractions import Fraction

QUESTION_TYPES = {"choice", "text", "open", "num", "spell", "tap", "judge", "order", "match", "hotspot"}
CHAT_AFTER = re.compile(r"^(start|end|(math|english|teasers):[1-9][0-9]*)$")
SCHEMA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "references", "schemas", "sheet.schema.json")
KEYPADS = {"digits", "fraction", "remainder"}


class Report:
    def __init__(self):
        self.errors, self.warnings = [], []

    def error(self, where, msg):
        self.errors.append(f"{where}: {msg}")

    def warn(self, where, msg):
        self.warnings.append(f"{where}: {msg}")


def squash(s):
    return re.sub(r"\s+", "", str(s)).lower()


def words(text):
    return len(text.split())


# ---- answer checks ----------------------------------------------------------------------------

ARITH = re.compile(r"^\s*(\d+)\s*([+\-−×x*÷/])\s*(\d+)\s*=?\s*$")
FRACTION_OF = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s+of\s+(\d+)\s*=?\s*$")


def expected_arith(prompt):
    """The answer to a bare sum like '47 + 38' or '29 ÷ 4', or None if the prompt isn't one."""
    m = ARITH.match(prompt)
    if m:
        a, op, b = int(m.group(1)), m.group(2), int(m.group(3))
        if op == "+":
            return str(a + b)
        if op in "-−":
            return str(a - b)
        if op in "×x*":
            return str(a * b)
        if op in "÷/" and b:
            q, r = divmod(a, b)
            return f"{q} r {r}" if r else str(q)
    m = FRACTION_OF.match(prompt)
    if m:
        value = Fraction(int(m.group(1)), int(m.group(2))) * int(m.group(3))
        return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"
    return None


def clock_names(hour, minute):
    """Ways a child's clock option can name this time."""
    nxt = hour % 12 + 1
    names = {f"{hour}:{minute:02d}"}
    if minute == 0:
        names |= {f"{hour} o'clock", f"{hour} o’clock", f"{hour}:00"}
    elif minute == 30:
        names.add(f"half past {hour}")
    elif minute == 15:
        names.add(f"quarter past {hour}")
    elif minute == 45:
        names.add(f"quarter to {nxt}")
    return {n.lower() for n in names}


def check_visual(where, item, rep):
    v = item.get("visual")
    if v is None:
        return
    if not isinstance(v, dict):
        rep.error(where, "visual must be an object")
        return
    kind = v.get("kind")
    options = item.get("options") or []
    idx = item.get("answerIndex")
    right = options[idx] if isinstance(idx, int) and 0 <= idx < len(options) else None
    if kind == "clock":
        h, m = v.get("hour"), v.get("minute", 0)
        if not isinstance(h, int) or not 1 <= h <= 12:
            rep.error(where, "clock hour must be a whole number 1-12")
            return
        if not isinstance(m, int) or not 0 <= m <= 59:
            rep.error(where, "clock minute must be a whole number 0-59")
            return
        if m % 5:
            rep.warn(where, "clock minute isn't a multiple of 5")
        # Only "what time does the clock show?" questions must have the clock's time as the answer;
        # others use the clock as a starting point (e.g. "it starts at 4:15 and lasts 30 minutes").
        if right is not None and "clock show" in str(item.get("prompt", "")).lower():
            names = clock_names(h, m)
            if right.strip().lower() not in names:
                rep.error(where, f"right option '{right}' doesn't match the clock ({h}:{m:02d}); expected one of {sorted(names)}")
            for i, o in enumerate(options):
                if i != idx and o.strip().lower() in names:
                    rep.error(where, f"option '{o}' also matches the clock, so two options are right")
    elif kind == "fraction":
        parts, shaded = v.get("parts"), v.get("shaded")
        if not isinstance(parts, int) or not 1 <= parts <= 24:
            rep.error(where, "fraction parts must be 1-24")
            return
        if not isinstance(shaded, int) or not 0 <= shaded <= parts:
            rep.error(where, "fraction shaded must be 0-parts")
            return
        if v.get("shape", "bar") not in ("bar", "pie"):
            rep.error(where, "fraction shape must be 'bar' or 'pie'")
        if right is not None and "shaded" in str(item.get("prompt", "")).lower():
            if squash(right) != f"{shaded}/{parts}":
                rep.error(where, f"right option '{right}' doesn't match the picture ({shaded}/{parts} shaded)")
    elif kind == "svg":
        check_svg(where, v, rep)
    else:
        rep.error(where, f"unknown picture kind '{kind}' (only 'clock', 'fraction' and 'svg')")


BANNED_TAGS = {"script", "foreignobject", "image", "iframe", "video", "audio", "animate",
               "animatemotion", "animatetransform", "set"}


def check_svg(where, v, rep):
    text = v.get("svg")
    if not isinstance(text, str) or not text.strip():
        rep.error(where, "an svg picture needs an 'svg' string")
        return
    if len(text) > 100_000:
        rep.error(where, f"svg is {len(text)} characters; the app's limit is 100,000")
    elif len(text) > 20_000:
        rep.warn(where, f"svg is {len(text)} characters; simpler drawings (under 5,000) load faster")
    h = v.get("height", 220)
    if not isinstance(h, int) or not 80 <= h <= 400:
        rep.error(where, "svg height must be a whole number 80-400")
    if re.search(r"<!(DOCTYPE|ENTITY)", text, re.I):
        rep.error(where, "svg must not contain DOCTYPE or ENTITY declarations")
        return
    try:
        root = ET.fromstring(text)
    except ET.ParseError as e:
        rep.error(where, f"svg isn't valid XML: {e}")
        return
    local = lambda tag: tag.rsplit("}", 1)[-1].lower()
    if local(root.tag) != "svg":
        rep.error(where, "svg must start with an <svg> element")
    if not root.get("viewBox"):
        rep.error(where, "svg needs a viewBox (the app rejects it otherwise)")
    if not root.tag.startswith("{http://www.w3.org/2000/svg}"):
        rep.error(where, "svg needs xmlns='http://www.w3.org/2000/svg'")
    shapes = 0
    for el in root.iter():
        tag = local(el.tag)
        if tag in BANNED_TAGS:
            rep.error(where, f"svg uses <{tag}>, which isn't allowed")
        if tag in ("rect", "circle", "ellipse", "line", "polyline", "polygon", "path", "text", "use"):
            shapes += 1
        for name, value in el.attrib.items():
            n = local(name)
            if n.startswith("on"):
                rep.error(where, f"svg has an event attribute '{n}', which isn't allowed")
            if n == "href" and not value.startswith("#"):
                rep.error(where, f"svg links to '{value[:40]}'; only links inside the drawing (#id) work")
            if re.search(r"url\(\s*['\"]?(?!#)", value):
                rep.error(where, f"svg uses url(...) to something outside the drawing in '{n}'")
        if tag == "style" and re.search(r"url\(\s*['\"]?(?!#)|@import", el.text or ""):
            rep.error(where, "svg <style> loads something from outside the drawing")
    if shapes == 0:
        rep.error(where, "svg draws nothing (no shapes or text)")


def check_choice(where, item, rep):
    options = item.get("options")
    if not isinstance(options, list) or not 2 <= len(options) <= 4 or not all(isinstance(o, str) and o.strip() for o in options):
        rep.error(where, "options must be 2-4 non-empty strings")
        return
    if len({squash(o) for o in options}) != len(options):
        rep.error(where, "two options are the same")
    idx = item.get("answerIndex")
    if not isinstance(idx, int) or not 0 <= idx < len(options):
        rep.error(where, "answerIndex must point at one of the options (0-based)")


def check_typed_answer(where, item, rep, math_prompt):
    answer = item.get("answer")
    if not isinstance(answer, str) or not answer.strip():
        rep.error(where, "needs an 'answer' string")
        return
    keypad = item.get("keypad", "digits")
    if keypad not in KEYPADS:
        rep.error(where, f"keypad must be one of {sorted(KEYPADS)}")
    for a in [answer] + list(item.get("accept") or []):
        a = squash(a)
        if not re.fullmatch(r"\d+(r\d+|/\d+)?", a):
            rep.error(where, f"answer '{a}' can't be typed on the number keys (digits, 'r' or '/' only)")
        if "r" in a and keypad != "remainder":
            rep.error(where, "answer has 'r', so keypad must be 'remainder'")
        if "/" in a and keypad != "fraction":
            rep.error(where, "answer has '/', so keypad must be 'fraction'")
    prompt = str(item.get("prompt", ""))
    if math_prompt and len(prompt) <= 16 and prompt.rstrip().endswith("=") and prompt.count("=") == 1:
        rep.warn(where, "short prompt ends in '=', and the app adds ' =' itself (shows '... = =')")
    want = expected_arith(prompt)
    if want is not None and squash(want) not in {squash(answer)} | {squash(a) for a in item.get("accept") or []}:
        rep.error(where, f"'{prompt}' should be {want}, but the answer says {answer}")


# ---- sections ---------------------------------------------------------------------------------

def check_math(m, rep, ids):
    if not isinstance(m, dict):
        rep.error("math", "must be an object")
        return
    probs = m.get("problems")
    if not isinstance(probs, list) or not probs:
        rep.error("math", "problems must be a non-empty list")
        return
    for key in ("label", "skill"):
        if not m.get(key):
            rep.warn("math", f"no '{key}'")
    if not isinstance(m.get("targetSeconds", 0), (int, float)):
        rep.error("math", "targetSeconds must be a number")
    for i, p in enumerate(probs):
        where = f"math problem {i + 1} ({p.get('id', '?') if isinstance(p, dict) else '?'})"
        if not isinstance(p, dict):
            rep.error(where, "must be an object")
            continue
        check_id(where, p, ids, rep)
        if not isinstance(p.get("prompt"), str) or not p["prompt"].strip():
            rep.error(where, "needs a prompt")
        if p.get("options") is not None:
            check_choice(where, p, rep)
        else:
            check_typed_answer(where, p, rep, math_prompt=True)
        check_visual(where, p, rep)
        check_tags(where, p, rep)
        right = (p.get("options") or [None])[p["answerIndex"]] if p.get("options") and isinstance(p.get("answerIndex"), int) and 0 <= p["answerIndex"] < len(p["options"]) else p.get("answer")
        check_hints(where, p, right, rep)
    if not 5 <= len(probs) <= 30:
        rep.warn("math", f"{len(probs)} problems; 10-20 suits one day")


def check_question(where, q, rep):
    t = q.get("type", "text")
    if t not in QUESTION_TYPES:
        rep.error(where, f"type must be one of {sorted(QUESTION_TYPES)}")
        return
    prompt = q.get("prompt", "")
    if t not in ("spell", "judge") and (not isinstance(prompt, str) or not prompt.strip()):
        rep.error(where, "needs a prompt")
    if t == "choice":
        check_choice(where, q, rep)
    elif t == "num":
        check_typed_answer(where, q, rep, math_prompt=False)
    elif t == "text":
        if not q.get("accept"):
            rep.error(where, "text questions need 'accept' (the answers to mark right)")
    elif t in ("spell", "judge"):
        word = q.get("word")
        if not isinstance(word, str) or not word.strip():
            rep.error(where, f"{t} questions need a 'word'")
        elif t == "spell":
            if not re.fullmatch(r"[A-Za-z']+", word):
                rep.error(where, f"spelling word '{word}' must be letters only (the letter keys have nothing else)")
            if word.lower() in str(prompt).lower():
                rep.error(where, "the spelling word appears in the prompt, which gives it away")
            if not q.get("sentence"):
                rep.warn(where, "no sentence; one helps the child hear which word is meant")
    elif t == "tap":
        sentence, accept = q.get("sentence"), q.get("accept")
        if not sentence or not accept:
            rep.error(where, "tap questions need 'sentence' and 'accept'")
        else:
            bare = {re.sub(r"[^a-z0-9'-]", "", w.lower()) for w in sentence.split()}
            for a in accept:
                if a.lower() not in bare:
                    rep.error(where, f"accepted word '{a}' isn't in the sentence")
    elif t == "order":
        items = q.get("items")
        if not isinstance(items, list) or not 2 <= len(items) <= 8 or not all(isinstance(i, str) and i.strip() for i in items):
            rep.error(where, "order needs 'items': 2-8 strings in the right order")
        elif len({squash(i) for i in items}) != len(items):
            rep.error(where, "order items must all be different")
    elif t == "match":
        pairs = q.get("pairs")
        if not isinstance(pairs, list) or not 2 <= len(pairs) <= 6 or not all(
                isinstance(p, list) and len(p) == 2 and all(isinstance(x, str) and x.strip() for x in p) for p in pairs):
            rep.error(where, "match needs 'pairs': 2-6 [left, right] pairs of strings")
        else:
            for side, name in ((0, "left"), (1, "right")):
                if len({squash(p[side]) for p in pairs}) != len(pairs):
                    rep.error(where, f"two {name} items in match are the same, so a pair is ambiguous")
    elif t == "hotspot":
        v, spots = q.get("visual"), q.get("spots")
        if not isinstance(v, dict) or v.get("kind") != "svg":
            rep.error(where, "hotspot needs an svg picture")
        if not isinstance(spots, list) or not 1 <= len(spots) <= 10:
            rep.error(where, "hotspot needs 1-10 spots")
        else:
            vb = None
            if isinstance(v, dict) and isinstance(v.get("svg"), str):
                m = re.search(r"viewBox=['\"]\s*([-\d.]+)[\s,]+([-\d.]+)[\s,]+([-\d.]+)[\s,]+([-\d.]+)", v["svg"])
                vb = tuple(float(x) for x in m.groups()) if m else None
            for k, sp in enumerate(spots):
                if not isinstance(sp, dict) or not all(isinstance(sp.get(c), (int, float)) for c in ("x", "y", "r")):
                    rep.error(where, f"spot {k + 1} needs numbers x, y, r")
                    continue
                if sp["r"] <= 0:
                    rep.error(where, f"spot {k + 1} radius must be above 0")
                if vb and not (vb[0] <= sp["x"] <= vb[0] + vb[2] and vb[1] <= sp["y"] <= vb[1] + vb[3]):
                    rep.error(where, f"spot {k + 1} is outside the picture's viewBox")
                if vb and sp["r"] < vb[2] / 20:
                    rep.warn(where, f"spot {k + 1} is small (r {sp['r']}); make it at least {vb[2] / 20:g} so small fingers can hit it")
    check_visual(where, q, rep)
    check_tags(where, q, rep)
    check_hints(where, q, expected_of(q), rep, needed=t != "judge")


def expected_of(q):
    t = q.get("type", "text")
    if t == "choice":
        o, i = q.get("options") or [], q.get("answerIndex")
        return o[i] if isinstance(i, int) and 0 <= i < len(o) else None
    if t == "num":
        return q.get("answer")
    if t in ("spell",):
        return q.get("word")
    if t in ("text", "tap"):
        return (q.get("accept") or [None])[0]
    return None


def gives_away(hint, answer):
    """Same rule as the genie and the app: a hint must not contain the answer."""
    if not answer:
        return False
    a = str(answer).strip()
    if re.fullmatch(r"[\d\s./rR]+", a):
        parts = [p for p in re.split(r"\s*[rR]\s*|\s+", a) if p]
        # A number counts unless it's part of a longer number or a decimal ("17." ending a sentence counts).
        return all(re.search(rf"(?<!\d)(?<!\d\.){re.escape(p)}(?!\d)(?!\.\d)", hint) for p in parts)
    return squash(a) in squash(hint)


def check_hints(where, item, answer, rep, needed=True):
    hints = item.get("hints")
    if hints is None:
        if needed:
            rep.warn(where, "no hints (add two: a wish-1 nudge and a wish-2 method hint)")
        return
    if not isinstance(hints, list) or not 1 <= len(hints) <= 2 or not all(isinstance(h, str) and h.strip() for h in hints):
        rep.error(where, "hints must be 1-2 non-empty strings")
        return
    for k, h in enumerate(hints):
        if gives_away(h, answer):
            rep.error(where, f"hint {k + 1} gives the answer away: '{h}'")
        if len(h.split()) > 30:
            rep.warn(where, f"hint {k + 1} is long ({len(h.split())} words); keep it under 25")


def check_tags(where, item, rep):
    tags, d = item.get("tags"), item.get("difficulty")
    if tags is None:
        rep.warn(where, "no tags (add a theme and a kind, e.g. [\"robots\", \"word-problem\"])")
    elif not isinstance(tags, list) or not all(isinstance(t, str) and t for t in tags):
        rep.error(where, "tags must be a list of strings")
    if d is not None and (not isinstance(d, int) or not 1 <= d <= 5):
        rep.error(where, "difficulty must be a whole number 1-5")


def check_teasers(t, rep, ids):
    if not isinstance(t, dict) or not isinstance(t.get("questions"), list) or not t["questions"]:
        rep.error("teasers", "needs a non-empty 'questions' list")
        return
    for i, q in enumerate(t["questions"]):
        where = f"teaser {i + 1} ({q.get('id', '?') if isinstance(q, dict) else '?'})"
        if not isinstance(q, dict):
            rep.error(where, "must be an object")
            continue
        check_id(where, q, ids, rep)
        check_question(where, q, rep)


def check_chats(chats, d, rep):
    if not isinstance(chats, list):
        rep.error("chats", "must be a list")
        return
    sizes = {"math": len((d.get("math") or {}).get("problems") or []),
             "english": len((d.get("english") or {}).get("questions") or []),
             "teasers": len((d.get("teasers") or {}).get("questions") or [])}
    seen = set()
    for i, c in enumerate(chats):
        where = f"chat {i + 1}"
        if not isinstance(c, dict) or not isinstance(c.get("prompt"), str) or not c["prompt"].strip():
            rep.error(where, "needs a prompt")
            continue
        after = c.get("after", "start")
        if not CHAT_AFTER.match(str(after)):
            rep.error(where, "after must be start, end, or like math:3")
        elif ":" in after:
            part, n = after.split(":")
            if int(n) > sizes[part]:
                rep.error(where, f"after {after}, but {part} has only {sizes[part]} questions, so it would never appear")
        opts = c.get("options")
        if opts is not None and (not isinstance(opts, list) or not 2 <= len(opts) <= 6):
            rep.error(where, "options must be 2-6 strings (or leave them out for a typed answer)")
        cid = c.get("id")
        if cid in seen:
            rep.error(where, f"id '{cid}' is used twice")
        seen.add(cid)
    if len(chats) > 4:
        rep.warn("chats", f"{len(chats)} chats; 2-3 a day is plenty")


def check_schema(d, rep):
    """Also check against the JSON Schema, if the jsonschema package is installed."""
    try:
        import jsonschema
    except ImportError:
        return
    try:
        with open(SCHEMA, encoding="utf-8") as f:
            schema = json.load(f)
    except OSError:
        return
    for e in jsonschema.Draft202012Validator(schema).iter_errors(d):
        path = "/".join(str(p) for p in e.absolute_path) or "file"
        rep.error(f"schema {path}", e.message[:160])


def check_english(e, rep, ids):
    if not isinstance(e, dict):
        rep.error("english", "must be an object")
        return
    passage, questions = e.get("passage"), e.get("questions") or []
    if passage is not None:
        if not isinstance(passage, dict) or not isinstance(passage.get("text"), str) or not passage["text"].strip():
            rep.error("english passage", "needs 'text'")
        else:
            n = words(passage["text"])
            wc = passage.get("wordCount")
            if wc is not None and wc != n:
                rep.error("english passage", f"wordCount is {wc} but the text has {n} words")
            if not passage.get("title"):
                rep.warn("english passage", "no title")
            check_visual("english passage", passage, rep)
    if passage is None and not questions:
        rep.error("english", "needs a passage or at least one question")
    if not isinstance(questions, list):
        rep.error("english", "questions must be a list")
        return
    for i, q in enumerate(questions):
        where = f"english question {i + 1} ({q.get('id', '?') if isinstance(q, dict) else '?'})"
        if not isinstance(q, dict):
            rep.error(where, "must be an object")
            continue
        check_id(where, q, ids, rep)
        check_question(where, q, rep)


def check_id(where, item, ids, rep):
    i = item.get("id")
    if not isinstance(i, str) or not i:
        rep.warn(where, "no id (the app makes one up, but results are easier to read with one)")
        return
    if i in ids:
        rep.error(where, f"id '{i}' is used twice")
    ids.add(i)


def validate(path):
    rep = Report()
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        rep.error("file", f"not valid JSON: {e}")
        return rep
    if not isinstance(d, dict):
        rep.error("file", "must be a JSON object")
        return rep
    if d.get("schemaVersion") != 1:
        rep.warn("file", "schemaVersion should be 1")
    date = d.get("date")
    if not isinstance(date, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        rep.error("file", "date must be YYYY-MM-DD")
    else:
        name = os.path.basename(path)
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.json", name) and name != date + ".json":
            rep.error("file", f"date {date} doesn't match the file name {name}")
    if not d.get("title"):
        rep.warn("file", "no title (the child sees \"Today's practice\")")
    ids = set()
    if "math" in d:
        check_math(d["math"], rep, ids)
    if "english" in d:
        check_english(d["english"], rep, ids)
    if "teasers" in d:
        check_teasers(d["teasers"], rep, ids)
    if "chats" in d:
        check_chats(d["chats"], d, rep)
    check_schema(d, rep)
    tasks = d.get("paperTasks")
    if tasks is not None:
        if not isinstance(tasks, list):
            rep.error("paperTasks", "must be a list")
        else:
            for i, t in enumerate(tasks):
                if not isinstance(t, dict) or not t.get("instruction"):
                    rep.error(f"paper task {i + 1}", "needs an instruction")
                else:
                    check_id(f"paper task {i + 1}", t, ids, rep)
    if not any(k in d for k in ("math", "english", "teasers", "paperTasks")):
        rep.error("file", "has no math, english, teasers or paperTasks")
    return rep


def main(paths):
    if not paths:
        print(__doc__.strip())
        return 2
    bad = False
    for p in paths:
        rep = validate(p)
        status = "OK" if not rep.errors else "PROBLEMS"
        print(f"{p}: {status} ({len(rep.errors)} errors, {len(rep.warnings)} warnings)")
        for e in rep.errors:
            print(f"  ERROR    {e}")
        for w in rep.warnings:
            print(f"  warning  {w}")
        bad = bad or bool(rep.errors)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
