#!/usr/bin/env python3
"""Build a learner profile (references/learner-profile.md) from Daily Practice result files.

Usage:
  python3 make_profile.py --dir path/to/results --grade 4 --age 9 --name Arjun > profile.json
  python3 make_profile.py --github BharanitharanR/daily-practice-results --grade 4 > profile.json

--dir reads every *.json in a folder (for example a downloaded copy of the results repo's results/).
--github reads the repo's results/ folder with the GitHub CLI (gh), which must be logged in.
Add --review reviews/2026-10-10.json to include the latest review from the daily-practice-review skill.
Paste the output into the daily-practice-sheet skill when it asks for the learner profile.
Needs only Python 3.9+ (and gh for --github).
"""
import argparse
import datetime
import json
import os
import statistics
import subprocess
import sys

MAX_DAYS = 10
MAX_LIST = 8


def load_dir(path):
    out = []
    for name in sorted(os.listdir(path)):
        if name.endswith(".json"):
            with open(os.path.join(path, name), encoding="utf-8") as f:
                try:
                    out.append(json.load(f))
                except json.JSONDecodeError:
                    print(f"skipping {name}: not valid JSON", file=sys.stderr)
    return out


def load_github(repo):
    def gh(*args):
        return subprocess.run(["gh", "api", *args], check=True, capture_output=True, text=True).stdout

    listing = json.loads(gh(f"repos/{repo}/contents/results"))
    out = []
    for f in listing:
        if f.get("type") == "file" and f["name"].endswith(".json"):
            raw = gh(f"repos/{repo}/contents/results/{f['name']}", "-H", "Accept: application/vnd.github.raw+json")
            out.append(json.loads(raw))
    return out


def q_of(item):
    return str(item.get("q", item.get("prompt", ""))).removesuffix(" =").strip()


def missed(items):
    return [{"q": q_of(i), "expected": i.get("expected", ""), "given": i.get("given", ""),
             **({"skill": i["skill"]} if i.get("skill") else {})}
            for i in items if i.get("correct") is False][:MAX_LIST]


def slow(items, limits=None):
    """Right answers slower than the level's speed target, or than twice the typical time."""
    right = [i for i in items if i.get("correct") is True and isinstance(i.get("ms"), (int, float))]
    if not right:
        return []
    typical = statistics.median(i["ms"] for i in right)
    out = []
    for i in right:
        limit = (limits or {}).get(i.get("level")) or 2 * typical
        if i["ms"] > limit:
            out.append({"q": q_of(i), "ms": int(i["ms"])})
    return sorted(out, key=lambda x: -x["ms"])[:MAX_LIST]


def checkup_entry(r):
    e = {"name": r.get("name"), "date": r.get("date") or str(r.get("finishedAt", ""))[:10]}
    if r.get("kind") == "writing":
        w = r.get("writing") or {}
        e["sentences"] = w.get("sentences")
        e["minutes"] = w.get("minutes")
        e["workOn"] = [k for k, v in (w.get("ratings") or {}).items() if v != "yes"]
        return e
    e["secureLevel"] = r.get("secureLevel")
    e["stoppedAt"] = r.get("stoppedAt")
    if r.get("stoppedEarly"):
        e["stoppedEarly"] = True
    e["levels"] = [{k: l.get(k) for k in ("name", "correct", "asked", "passed", "medianMs", "fluentMs")}
                   for l in r.get("levels") or []]
    items = r.get("items") or []
    limits = {l["name"]: l["fluentMs"] for l in r.get("levels") or [] if l.get("fluentMs")}
    e["slow"] = slow(items, limits)
    e["missed"] = missed(items)
    if r.get("passages"):
        e["reading"] = [{k: p.get(k) for k in ("title", "name", "wordsCorrectPerMinute", "accuracy",
                                                "questionsCorrect", "questions", "passed")}
                        for p in r["passages"]]
    return e


def day_entry(r):
    e = {"date": r.get("date"), "title": r.get("contentTitle")}
    m = r.get("math")
    if m:
        e["math"] = {"skill": m.get("skill"), "label": m.get("label"), "correct": m.get("firstPassCorrect"),
                     "total": m.get("total"), "firstPassSeconds": m.get("firstPassSeconds"),
                     "targetSeconds": m.get("targetSeconds"), "missed": missed(m.get("items") or []),
                     "slow": slow(m.get("items") or [])}
    en = r.get("english")
    if en:
        rd = en.get("reading") or {}
        e["english"] = {"correct": en.get("firstPassCorrect"), "marked": en.get("autoMarked"),
                        "wordsCorrectPerMinute": rd.get("wordsCorrectPerMinute"), "mistakes": rd.get("mistakes"),
                        "missed": missed(en.get("items") or [])}
        if en.get("passageTitle"):
            e["english"]["passageTitle"] = en["passageTitle"]
    tasks = r.get("paperTasks") or []
    if tasks:
        e["paperTasks"] = {"done": sum(1 for t in tasks if t.get("done")), "total": len(tasks)}
    return e


def build(results, args):
    checks = sorted((r for r in results if r.get("type") == "checkup"), key=lambda r: str(r.get("finishedAt")))
    days = sorted((r for r in results if r.get("type") != "checkup" and r.get("date")),
                  key=lambda r: str(r.get("completedAt") or r.get("date")), reverse=True)
    latest = {}
    for r in checks:
        latest[r.get("station")] = r  # the newest result per station wins
    learner = {k: v for k, v in (("name", args.name), ("grade", args.grade), ("age", args.age),
                                 ("locale", args.locale)) if v is not None}
    profile = {"profileVersion": 1, "learner": learner, "asOf": datetime.date.today().isoformat(),
               "checkup": {sid: checkup_entry(r) for sid, r in latest.items() if sid},
               "recentDays": [day_entry(r) for r in days[:MAX_DAYS]]}
    if args.notes:
        profile["parentNotes"] = args.notes
    if args.review:
        with open(args.review, encoding="utf-8") as f:
            profile["review"] = json.load(f)
    return profile


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--dir", help="folder of result JSON files")
    src.add_argument("--github", metavar="OWNER/REPO", help="results repo, read with the gh CLI")
    p.add_argument("--name")
    p.add_argument("--grade", type=int)
    p.add_argument("--age", type=int)
    p.add_argument("--locale", default="en-IN")
    p.add_argument("--notes", help="parent notes: interests, worries, school topics")
    p.add_argument("--review", help="a review JSON from the daily-practice-review skill")
    args = p.parse_args()
    results = load_dir(args.dir) if args.dir else load_github(args.github)
    json.dump(build(results, args), sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
