"""
Pairing a tablet: a grown-up runs `python -m daily_practice_genie.pair` on the Mac,
which prints a 6-digit code; typing that code (and the Mac's address) on the tablet
fetches the device key, so it never has to be copied or shown.

A code lasts 10 minutes, works once, and is thrown away after 5 wrong tries - a
million possible codes against 5 tries. pair_claim is the only genie skill that
works without the device key (agent_executor.PUBLIC_SKILLS).
"""
import secrets
import sqlite3
import time
from typing import Any, Dict

from daily_practice_genie.constants import AGENT_ID
from daily_practice_genie.skills import family
from mesh.lib.paths import state_db_path
from mesh.lib.secrets_vault import get_secret

CODE_TTL_SECONDS = 600
MAX_TRIES = 5


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(state_db_path(AGENT_ID))
    conn.execute('CREATE TABLE IF NOT EXISTS pairing (code TEXT NOT NULL, expires_at REAL NOT NULL, tries INTEGER NOT NULL)')
    return conn


def new_code() -> str:
    """A fresh code; any older one stops working."""
    code = f'{secrets.randbelow(1_000_000):06d}'
    conn = _db()
    conn.execute('DELETE FROM pairing')
    conn.execute('INSERT INTO pairing (code, expires_at, tries) VALUES (?, ?, 0)', (code, time.time() + CODE_TTL_SECONDS))
    conn.commit()
    return code


async def claim(code: str) -> Dict[str, Any]:
    conn = _db()
    row = conn.execute('SELECT code, expires_at, tries FROM pairing').fetchone()
    if row is None or time.time() > row[1] or row[2] >= MAX_TRIES:
        conn.execute('DELETE FROM pairing')
        conn.commit()
        return {'paired': False, 'reason': 'No pairing code is active. On the Mac, run: python -m daily_practice_genie.pair'}
    if not secrets.compare_digest(str(code or '').strip(), row[0]):
        conn.execute('UPDATE pairing SET tries = tries + 1')
        conn.commit()
        return {'paired': False, 'reason': 'That code is not right.'}
    conn.execute('DELETE FROM pairing')
    conn.commit()
    me = await family.ping()
    return {'paired': True, 'device_key': get_secret('GENIE_DEVICE_KEY'), 'url': me['url'], 'name': me['name']}
