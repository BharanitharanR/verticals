"""
Print a pairing code for the Daily Practice tablet.

    python -m daily_practice_genie.pair

On the tablet: Grown-ups -> Genie -> Pair with a code. Enter this Mac's address and the code.
"""
import asyncio

from daily_practice_genie.skills import family, pairing


async def main() -> None:
    code = pairing.new_code()
    me = await family.ping()
    print(f'\nPairing code: {code[:3]} {code[3:]}   (works once, for 10 minutes)\n')
    print("On the tablet: Grown-ups -> Genie -> Pair with a code, then enter:")
    print(f'  address: {me["url"]}')
    print(f'  code:    {code}\n')


if __name__ == '__main__':
    asyncio.run(main())
